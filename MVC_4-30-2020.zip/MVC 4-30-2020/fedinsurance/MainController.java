package fedinsurance;

public class MainController {

    public static void main(String[] args) {
        Supervisor testSupervisor = new Supervisor("EI75", "CIO");
        Salary testSalary = new Salary(50000, 60000);
        Employee testEmloyee = new Employee("123","Cal Capra", );
        ViewController controller = new ViewController();
        controller.printEmployee(testEmployee);
    }

}
